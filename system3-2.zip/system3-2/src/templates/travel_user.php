<div class="options-container profile-options-container travel-record">
    <!-- <div class="t-option option">
            <div class="option-left">
                <p>Dec 07, 2020</p>
            </div>
            <div class="option-right">
                <p>Barangay 1 San Mateo, Isabela</p>
            </div>
        </div>

        <div class="t-option option">
            <div class="option-left">
                <p>Dec 07, 2020</p>
            </div>
            <div class="option-right">
                <p>Barangay 1 San Mateo, Isabela</p>
            </div>
        </div>

        <div class="t-option option">
            <div class="option-left">
                <p>Dec 07, 2020</p>
            </div>
            <div class="option-right">
                <p>Barangay 1 San Mateo, Isabela</p>
            </div>
        </div>
    </div> -->
</div>
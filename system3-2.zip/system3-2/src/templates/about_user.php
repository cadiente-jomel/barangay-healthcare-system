<div class="citizen-personal-info">
    <ul class="personal-info">

    <?php 
        include('../includes/db.ini.php');
        include('../includes/detailed.php');
    ?>
        <!-- <li>First Name: <span clsas="info-first">Susan</span></li>
        <li>Last Name: <span clsas="info-last">Williams</span></li>
        <li>Status: <span clsas="info-status">Positive</span></li>
        <li>Day of Quarantine: <spa clsas="info-day">14days</spa></li>
        <li>Age: <span clsas="info-age">25</span></li>
        <li>Occupation: <span clsas="info-occupation">Stock Investor</span> </li>
        <li>Civil Status: <span clsas="info-civil">Single</span></li>
        <li>Covid Case: <span clsas="info-case">Asymptomatic</span></li> -->
    </ul>
</div>
<div class="options-container profile-options-container contact-record">
    <!-- <div class="interact-option">
        <div class="interact-option-left">
            <p>Dec 07, 2020</p>
        </div>
        <div class="interact-option-middle">
            <p>John Bravo</p>
        </div>
        <div class="interact-option-right">
            <span></span>
            <span>Barangay 1 San Mateo, Isabela</span>
        </div>
    </div>

    <div class="interact-option">
        <div class="interact-option-left">
            <p>Dec 07, 2020</p>
        </div>
        <div class="interact-option-middle">
            <p>Susan William</p>
        </div>
        <div class="interact-option-right">
            <p>Villa Magat San Mateo, Isabela</p>
        </div>
    </div>

    <div class="interact-option">
        <div class="option-left">
            <p>Dec 07, 2020</p>
        </div>
        <div class="interact-option-middle">
            <p>Daniel Crisostomo</p>
        </div>
        <div class="interact-option-right">
            <p>Old Centro 1 San Mateo, Isabela</p>
        </div>
    </div> -->

</div>
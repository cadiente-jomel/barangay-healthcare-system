<?php

$serverName = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "pandemic";

$conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);